/*
Departmental store management system to insert, display, delete,update and sale product
*/


/* start main funcion  */


#include <header.h>
int main()
{
	mainMenu();
	system("clear");
	return 0;
}

/* end of main	*/


