#include<header.h>
/*
void dbill()
{
    int i;
    for (i = 1; i <= 10; i++)
        printf("-");
    printf(" DEPARTMENTAL STORE ");
    for (i = 1; i <= 10; i++)
        printf("-");
    printf("\n\n");
    printf("CUSTOMER'S BILL\n");
    printf("SN.   Item Name     Quantity     Rate          Total\n");
}
*/
